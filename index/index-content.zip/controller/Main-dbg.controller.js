// @ts-ignore
sap.ui.define([
		"sap/ui/core/mvc/Controller"
	],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
	function (Controller) {
		"use strict";

		return Controller.extend("com.wise.portal.index.controller.Main", {
			onInit: function () {

                var toolPage = new sap.tnt.ToolPage("TntToolPage", {
				sideExpanded: false,
				header: new sap.tnt.ToolHeader({
					content: [
						new sap.m.Button("idBtnMenu", {
							visible: true,
							icon: "sap-icon://menu2",
							press: function () {
								toolPage.getSideExpanded();
								toolPage.setSideExpanded(!toolPage.getSideExpanded());
							},
							type: "Transparent"
						}).addStyleClass("ZsapBtnMenu"),
						new sap.m.Button({
							icon: "sap-icon://home",
							type: "Transparent"
						}).addStyleClass("ZsapBtnTP"),
						new sap.m.Title({
							text: "{i18n>ToolPage.Header.ToolHeader.Title}",
							textAlign: "Center"
						}),
						new sap.m.ToolbarSpacer(),
						new sap.m.Button("idBtnUser", {
							icon: "sap-icon://account",
							press: function (event) {
								var oPopover = new Popover({
									showHeader: false,
									placement: PlacementType.Bottom,
									content: [
										new Button({
											text: "Cambiar Contraseña"
										}),
										new Button({
											text: "Ayuda",
											type: ButtonType.Transparent
										}),
										new Button({
											text: "Salir",
											type: ButtonType.Transparent
										})
									]
								}).addStyleClass('sapMOTAPopover sapTntToolHeaderPopover');

								oPopover.openBy(event.getSource());
							},
							type: "Transparent"
						}).addStyleClass("ZsapMBtnTP")
					]
				}),
				sideContent: new sap.tnt.SideNavigation({
					expanded: true,
					itemSelect: function (oEvt) {
						var item = oEvt.getParameter('item');
						if (item.getKey() === "0"){
							return;
						}
						toolPage.setSideExpanded(false);
					},
					item: new sap.tnt.NavigationList("idNavigationLisMaster", {
						expanded: true,
						selectedKey: "0",
						items: [
							new sap.tnt.NavigationListItem({
								text: "{i18n>ToolPage.NavigationList.1}",
								icon: "sap-icon://course-book",
								key: "0",
								visible: true,
								items: [
									new sap.tnt.NavigationListItem({
										text: "{i18n>ToolPage.NavigationList.NavigationListItem.1}",
										key: "1"
									}),
									new sap.tnt.NavigationListItem({
										text: "{i18n>ToolPage.NavigationList.NavigationListItem.2}",
										key: "2"
									}),
									new sap.tnt.NavigationListItem({
										text: "{i18n>ToolPage.NavigationList.NavigationListItem.3}",
										key: "3"
									})
								]
							})
						]
					})
				})
			});

			var sToolPage = this.byId("pageId");
			sToolPage.addContent(toolPage);

			}
		});
	});
